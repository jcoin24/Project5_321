﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MapGen;

public class BetterMapTile
{
    public MapTile tile = new MapTile();
    public MapTile parent = new MapTile();
    public int gCost = 10;
    public int hCost = 1;
    public int fCost = 0;
    public int x;
    public int y;

    public BetterMapTile(MapTile _tile, MapTile _parent)
    {
        tile = _tile;
        parent = _parent;
        x = _tile.X;
        y = _tile.Y;
    }

    public List<BetterMapTile> GetAdjacents(BetterMapTile[,] tile, int numWalls, int a, int b)
    {
        List<BetterMapTile> adjacents = new List<BetterMapTile>();

        for(int x = -1; x <= 1; x++)
        {
            for (int y = -1; y <= 1; y++)
            {
                if(x == 0 && y == 0)
                {
                    continue;
                }

                int checkX = a + x;
                int checkY = b + y;

                if (checkX >= 0 && checkX < numWalls && checkY >= 0 && checkY < numWalls)
                {
                    adjacents.Add(tile[checkX, checkY]);
                }
            }

        }
        return adjacents;
    }

    public MapTile GetTile()
    {
        return tile;
    }

    public MapTile GetParent()
    {
        return parent;
    }

    public void setTile(MapTile _tile)
    {
        tile = _tile;
    }

    public void setParent(MapTile _parent)
    {
        parent = _parent;
    }

    
}
