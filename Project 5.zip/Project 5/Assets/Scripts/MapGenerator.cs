﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MapGen;

public class MapGenerator : MonoBehaviour {

    public GameObject wall;
    public GameObject start;
    public GameObject end;
    public GameObject floor;
    public GameObject player;

    enum MapVersion {Perlin, Prim};
    [SerializeField]
    MapVersion currentMap;

    public int numWalls = 30;

    [Range(0.0f, 100.0f)] //Creates a slider in the inspector with the given range.
    public float PerlinSlider;

    [Range(0.0f, 1.0f)]
    public float PrimSlider;

    public MapTile[,] walls;
    public BetterMapTile[,] tile;

    public Vector3 pos;

    void MapStart()
    {
        switch (currentMap) //Basic case statement from last lecture
        {
            case MapVersion.Perlin: //Perlin Case Below
                PerlinGenerator perlinGen = new PerlinGenerator(); //Creates the map generator
                walls = perlinGen.MapGen(numWalls, numWalls, PerlinSlider); //Creates a map given a size and the specified value for that generator

                break;

            case MapVersion.Prim:
                PrimGenerator BaseMapGenerator = new PrimGenerator();
                walls = BaseMapGenerator.MapGen(numWalls, numWalls, PrimSlider);
                break;

            default:
                break;

        }

        tile = new BetterMapTile[numWalls, numWalls];
        for (int x = 0; x < numWalls; x++)
        {
            for (int y = 0; y < numWalls; y++)
            {
                tile[x, y] = new BetterMapTile(walls[x, y], walls[x, y]);
            }
        }

        //Loops through the array of tiles 
        for (int x = 0; x < numWalls; x++)
        {
            for (int y = 0; y < numWalls; y++)
            {
                //Instantiate the start tile when found && calls to spawn the player
                if(walls[x,y].IsStart)
                {
                    pos = Vector3.zero + new Vector3(walls[x, y].X, 0, walls[x, y].Y);
                    Instantiate(start, pos, Quaternion.identity);
                }

                //Instantiate the goal tile when found
                if (walls[x, y].IsGoal)
                {
                    pos = Vector3.zero + new Vector3(walls[x, y].X, 0, walls[x, y].Y);
                    Instantiate(end, pos, Quaternion.identity);
                }

                //Instantiate all walkable tiles to make the floor
                if(walls[x,y].Walkable && !walls[x,y].IsGoal && !walls[x, y].IsStart)
                {
                    pos = Vector3.zero + new Vector3(walls[x, y].X, 0, walls[x, y].Y);
                    Instantiate(floor, pos, Quaternion.identity);
                }

                //Instantiate all the walls 
                if (!walls[x, y].Walkable)
                {
                    pos = Vector3.zero + new Vector3(walls[x, y].X, 0.5f, walls[x, y].Y);
                    Instantiate(wall, pos, Quaternion.identity);
                }


            }
        }

        //Instantiate the perimeter wall
        for(int x = 0; x < numWalls; x++)
        {

            pos = Vector3.zero + new Vector3(walls[0, x].X-1, 0.5f, walls[0, x].Y);
            Instantiate(wall, pos, Quaternion.identity);

            pos = Vector3.zero + new Vector3(walls[x, 0].X, 0.5f, walls[x, 0].Y-1);
            Instantiate(wall, pos, Quaternion.identity);

            pos = Vector3.zero + new Vector3(walls[numWalls - 1, x].X+1, 0.5f, walls[numWalls - 1, x].Y);
            Instantiate(wall, pos, Quaternion.identity);

            pos = Vector3.zero + new Vector3(walls[x, numWalls - 1].X, 0.5f, walls[x, numWalls - 1].Y+1);
            Instantiate(wall, pos, Quaternion.identity);
        }

        //These create the corner not necessary just for my OCD
        pos = Vector3.zero + new Vector3(-1, 0.5f, -1);
        Instantiate(wall, pos, Quaternion.identity);

        pos = Vector3.zero + new Vector3(numWalls, 0.5f, -1);
        Instantiate(wall, pos, Quaternion.identity);

        pos = Vector3.zero + new Vector3(-1, 0.5f, numWalls);
        Instantiate(wall, pos, Quaternion.identity);

        pos = Vector3.zero + new Vector3(numWalls, 0.5f, numWalls);
        Instantiate(wall, pos, Quaternion.identity);
    }


    // Use this for initialization
    void Start ()
    {
        //Calls method to create the map
        MapStart();
        Astar();
    }

    // Update is called once per frame
    void Update () {

    }

    //Method to run A* algorithm in 
    void Astar()
    {
        int startX = 0;
        int startY = 0;

        int goalX = 0;
        int goalY = 0;
        //Moves the playewr to the start
        for (int x = 0; x < numWalls; x++)
        {
            for (int y = 0; y < numWalls; y++)
            {
                if (tile[x,y].GetTile().IsStart)
                {
                    startX = x;
                    startY = y;
                    player.transform.position = new Vector3(x, 1.5f, y);
                }
                if (tile[x,y].GetTile().IsGoal)
                {
                    goalX = x;
                    goalY = y;
                }
            }
        }

        BetterMapTile startTile = new BetterMapTile(walls[startX,startY], walls[startX, startY]);
        BetterMapTile goalTile = new BetterMapTile(walls[goalX, goalY], walls[goalX, goalY]);

        //Create todo  set 
        List<BetterMapTile> toDo = new List<BetterMapTile>();
        //Create done set
        List<BetterMapTile> done = new List<BetterMapTile>();
        // Adds starting node to the list
        toDo.Add(startTile);



        while (toDo.Count > 0)
        {
            BetterMapTile currentTile = toDo[0];

            for (int x = 1; x < toDo.Count; x++)
            {
                if (toDo[x].fCost < currentTile.fCost || toDo[x].fCost == currentTile.fCost && toDo[x].hCost < currentTile.hCost)
                {
                    currentTile = toDo[x];
                }
            }

            toDo.Remove(currentTile);
            done.Add(currentTile);


            if (currentTile.GetTile().IsGoal)
            {
                return;
            }


                    foreach (BetterMapTile neighbor in tile)
                    {
                        if (!neighbor.GetTile().Walkable || done.Contains(neighbor))
                        {
                            continue;
                        }
                        int newMove = currentTile.gCost + GetDistance(currentTile, neighbor);

                        if (newMove < neighbor.gCost || !toDo.Contains(neighbor))
                        {
                            int gCost = newMove;
                            int hCost = GetDistance(neighbor, goalTile);

                            neighbor.fCost = gCost + hCost;
                            neighbor.setParent(currentTile.GetTile());

                            if (!toDo.Contains(neighbor))
                            {
                                toDo.Add(neighbor);
                            }
                        }
                    }


           /*
           for (int x = 0; x < numWalls; x++)
            {
                for (int y = 0; y < numWalls; y++)
                {
                    Debug.Log("The f cost of " + x + " " + y + " " +tile[x,y].fCost);
                }
            }
            */
            followPath(startTile, goalTile);
        }
    }

    public MapTile Adjacent(BetterMapTile currentTile)
    {
        int minX=0;
        int minY=0;
        int minF;
        for (int x = -1; x <= 1; x++)
        {
            for (int y = -1; y <= 1; y++)
            {
                if (x == 0 && y == 0)
                {
                    continue;
                }

                int checkX = currentTile.GetTile().X + x;
                int checkY = currentTile.GetTile().Y + y;

                if (checkX >= 0 && checkX < numWalls && checkY >= 0 && checkY < numWalls)
                {
                   if (false)//tile[checkX, checkY].fCost <= minF)
                    {
                        minX = tile[checkX, checkY].x;
                        minY = tile[checkX, checkY].y;
                        minF = tile[checkX, checkY].fCost;
                        
                    }
                }
            }

        }

        return tile[minX, minY].GetTile();
    }


    void followPath(BetterMapTile start, BetterMapTile end)
    {
        List<MapTile> path = new List<MapTile>();
        BetterMapTile currentTile = end;

        /*
        while (!currentTile.GetTile().IsStart)
        {
            path.Add(currentTile.GetTile());
            currentTile.setTile(currentTile.parent);
        }
        */
        path.Reverse();
        //currentTile.setParent(tile[0,0].GetTile());
        Debug.Log(currentTile.GetTile().X + " "+ currentTile.GetTile().Y + " Parent " + currentTile.GetParent().X + " " + currentTile.GetParent().Y);

        for (int x = 0; x < path.Capacity; x++)
        {
            player.transform.position += new Vector3(path[x].X, 1.5f, path[x].Y);          
        }
    }

    int GetDistance(BetterMapTile a, BetterMapTile b)
    {
        int distX = Mathf.Abs(a.GetTile().X - b.GetTile().X);
        int distY = Mathf.Abs(a.GetTile().Y - b.GetTile().Y);

        if (distX > distY)
            return 12 * distX + 10 * (distX - distY);
        return 12 * distX + 10 * (distY - distX);
    }


}
