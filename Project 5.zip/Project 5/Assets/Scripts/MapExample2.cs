﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using MapGen; //Include at the top of your script, this is the map dll generator. 
//You will be able to access all properties given by the DLL this includes the generators and the MapTile class that you should use to store your map tiles and access them.


public class MapExample2 : MonoBehaviour {

enum MapVersion { Perlin, Prim }; //Enumeration from last lecture, helps with organization

[SerializeField] //Allows private variables to be rendered in the inspector and can be edited by the programmer
MapVersion currentMap; //This would be your current map version can be changed in the inspector for testing

[SerializeField]
public int mazeSize = 20; //Static size of maps. Should always be square maps. You can experiment with rectangular, just be prepared for some different math requirements in A*.

[Range(0.0f, 100.0f)] //Creates a slider in the inspector with the given range. Helpful for testing the Perlin and Prim factors
public float PerlinSlider;

[Range(0.0f, 1.0f)]
public float PrimSlider;

public MapTile[,] tiles1; //Where you actual map will be saved. A 2-Dimensional matrix that's size is determined by the map generators below.

void MapStart()
{
    switch (currentMap) //Basic case statement from last lecture
    {
        case MapVersion.Perlin: //Perlin Case Below
            PerlinGenerator perlinGen = new PerlinGenerator(); //Creates the map generator
            tiles1 = perlinGen.MapGen(mazeSize, mazeSize, PerlinSlider); //Creates a map given a size and the specified value for that generator
            break;

        case MapVersion.Prim:
            PrimGenerator BaseMapGenerator = new PrimGenerator();
            tiles1 = BaseMapGenerator.MapGen(mazeSize, mazeSize, PrimSlider);
            break;

        default:
            break;

    }

    //Instantiate your tiles down here
    //Example instantiation for a start tiles
    //Create your own method for spawning the start, end, walkable, and non walkable tiles for you map.

    //Instantiate(StartTile, new Vector3(currentTile.X, 0f, currentTile.Y), new Quaternion(), walkableTilesParent.transform);
}

// Use this for initialization
void Start () {
        MapStart();
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    
}
